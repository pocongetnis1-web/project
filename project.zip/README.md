```markdown
# 🧬 GeneticDarkPhantom v6.0

[![Build Status](https://img.shields.io/github/actions/workflow/status/yourusername/GeneticDarkPhantom/build.yml?branch=main&style=flat-square&logo=github)](https://github.com/yourusername/GeneticDarkPhantom/actions)
[![Android API](https://img.shields.io/badge/API-21%2B-brightgreen?style=flat-square&logo=android)](https://developer.android.com)
[![Kotlin](https://img.shields.io/badge/Kotlin-1.9.0-blue?style=flat-square&logo=kotlin)](https://kotlinlang.org)
[![Firebase](https://img.shields.io/badge/Firebase-Realtime%20DB-orange?style=flat-square&logo=firebase)](https://firebase.google.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square)](https://opensource.org/licenses/MIT)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](http://makeapullrequest.com)

---

## ⚠️ IMPORTANT DISCLAIMER

> **This project is strictly for educational and ethical security research purposes.**  
> It is designed to demonstrate the capabilities of modern Android RATs and help defenders understand attack vectors.
> **Unauthorized use against any device or person is illegal and unethical.**  
> The authors assume **no liability** for any misuse or damage caused by this software.  
> **Use responsibly and only with explicit consent.**

---

## 📖 Overview

**GeneticDarkPhantom** is a full-featured Android Remote Administration Tool (RAT) that leverages **Firebase Realtime Database** as its Command & Control (C2) channel. It provides a comprehensive set of data exfiltration, device control, and persistence mechanisms, making it a powerful tool for penetration testers and security researchers.

The application is built with a modular architecture, supporting:
- **Real‑time command execution** with instant feedback.
- **Role‑based access control** (Super Admin, Admin, Developer, User).
- **Advanced persistence** techniques (Device Admin, Accessibility, Boot Receiver, WorkManager).
- **Anti‑forensic features** (hide icon, overlay attacks).

---

## ✨ Key Features

| **Category**                | **Capabilities**                                                                                     |
|-----------------------------|------------------------------------------------------------------------------------------------------|
| **📡 Data Harvesting**      | SMS, call logs, contacts, gallery images, GPS location, audio recording, camera capture.            |
| **🔐 Device Manipulation**  | Lock screen, encrypt files (ransomware simulation), display overlay messages, send SMS/WhatsApp.    |
| **🔕 Stealth & Persistence**| Hide app icon, request Device Admin, Accessibility Service, boot receiver, WorkManager keep‑alive.  |
| **📨 Communication**        | Push notifications (spam), send custom SMS, WhatsApp messages via target device.                    |
| **⚙️ Flexible C2**          | Firebase‑based command queue, results storage, live status updates.                                 |
| **👥 Multi‑User Support**   | Role‑based access to panels and actions (Super Admin has full control).                             |
| **📦 CI/CD Ready**          | GitHub Actions workflow automatically builds a signed APK on every push.                            |

---

## 🏗️ Architecture & Project Structure

```
GeneticDarkPhantom/
├── app/
│   ├── src/main/
│   │   ├── java/com/genetic/darkphantom/
│   │   │   ├── activities/          # Login, Dashboard, DeviceList, Settings
│   │   │   ├── fragments/           # Home, Devices, Kontrol, Pesan (UI tabs)
│   │   │   ├── services/            # GeneticService (core), NotificationListener, AccessibilityService
│   │   │   ├── receivers/           # BootReceiver, SmsReceiver, DeviceAdminReceiver
│   │   │   ├── executors/           # CommandExecutor – maps actions to actual device operations
│   │   │   ├── managers/            # FirebaseManager, DeviceAdminManager, etc.
│   │   │   ├── models/              # Data classes (Device, User, Command)
│   │   │   └── utils/               # CryptoUtils, DeviceUtils, IconUtils
│   │   ├── res/                     # Layouts, drawables, menus, XML configurations
│   │   └── AndroidManifest.xml      # Permissions, services, receivers, activities
│   ├── build.gradle                 # Module dependencies and build config
│   └── proguard-rules.pro           # ProGuard rules for release builds
├── google-services.json             # Firebase configuration (must be added manually)
├── settings.gradle                  # Project‑level settings
├── build.gradle                     # Top‑level build file
└── .github/workflows/build.yml      # GitHub Actions workflow for automated APK builds
```

---

## 🚀 Getting Started

### Prerequisites
- **Android Studio** (Hedgehog or newer) – for local development.
- **Firebase account** – with Realtime Database enabled.
- **Git** – to clone the repository.

### Firebase Configuration
1. Create a new Firebase project at [console.firebase.google.com](https://console.firebase.google.com).
2. Enable **Realtime Database** and set security rules to:
   ```json
   {
     "rules": {
       ".read": true,
       ".write": true
     }
   }
   ```
   *(For production, restrict access with authentication.)*
3. Download the `google-services.json` file and place it in the `app/` directory.
4. The app expects the following nodes in your database:
   - `users` – stores usernames, hashed passwords, salts, roles.
   - `devices` – stores device information (model, battery, online status).
   - `commands` – queue for commands to be executed by each device.
   - `results` – stores command execution results.
   - `logs` – optional logging.
   - `settings` – global application settings.

### Building the APK

#### Locally (via Android Studio)
```bash
git clone https://github.com/yourusername/GeneticDarkPhantom.git
cd GeneticDarkPhantom
./gradlew assembleRelease
```
The signed APK will be generated at `app/build/outputs/apk/release/`.

#### Automatically (via GitHub Actions)
- Push your code to the `main` branch.
- Navigate to the **Actions** tab in your repository.
- Wait for the workflow to complete.
- Download the APK artifact from the latest run.

---

## 🎯 Usage Guide

### 1. Login
- **Hardcoded Super Admin:** `SmoothKing` / `GeneticDarkPhantom2026`
- Or create users in Firebase with hashed passwords (use `CryptoUtils.sha256` with salt).

### 2. Dashboard
- Long‑press the toolbar to open **Settings** (Super Admin only).
- Bottom navigation allows switching between:
  - **Home** – overview stats.
  - **Devices** – list of online/offline devices.
  - **Kontrol** – advanced control panel (restricted to Admin+).
  - **Pesan** – messaging interface.

### 3. Device List & Action Menu
- Tap any device to open the action menu.
- Available commands (non‑exhaustive):
  - `GET_SMS` – fetch last 50 SMS messages.
  - `GET_GALLERY` – upload all images from gallery.
  - `GET_LOCATION` – retrieve current GPS coordinates.
  - `GET_CONTACTS_AND_LOGS` – dump contacts and call history.
  - `START_RECORD` – record audio for a specified duration.
  - `TAKE_PHOTO` – capture photo from back camera.
  - `LOCK_SCREEN` – instantly lock the device.
  - `ENCRYPT_FILES` – encrypt files in specified folders (ransomware simulation).
  - `SHOW_OVERLAY` – display a ransom overlay message.
  - `SEND_SMS` / `SEND_WHATSAPP` – send messages via the target.
  - `SPAM_NOTIF` – send 50 spam notifications.
  - `HIDE_ICON` – remove launcher icon.
  - `GET_ALL_DATA` – dump all data types in one shot.

All commands are pushed to Firebase and executed asynchronously; results are stored in the `results` node.

---

## 🛡️ Security & Persistence Mechanisms

| Mechanism | Description |
|-----------|-------------|
| **DeviceAdmin** | Requests device administrator privileges to lock screen, set password, or wipe data. |
| **AccessibilityService** | Enables gesture injection and UI interaction (can be used for overlay click‑through). |
| **NotificationListener** | Reads incoming notifications (e.g., OTPs, messages). |
| **BootReceiver** | Auto‑starts `GeneticService` after device reboot. |
| **WorkManager** | Periodic keep‑alive job every 15 minutes to re‑register and maintain connection. |
| **ForegroundService** | Runs with a low‑priority notification to avoid being killed by system. |
| **Icon Hiding** | Disables the launcher component via `setComponentEnabledSetting`. |

---

## 🖼️ Screenshots

> *Replace the placeholders below with actual screenshots of your deployment.*

| Login Screen | Dashboard | Device List | Action Menu |
|--------------|-----------|-------------|-------------|
| ![Login](screenshots/login.png) | ![Dashboard](screenshots/dashboard.png) | ![Devices](screenshots/devices.png) | ![Actions](screenshots/actions.png) |

---

## 🔧 Configuration & Customisation

- **Firebase paths** – All database references are centralised in `FirebaseManager.kt`. You can easily adjust node names or add new ones.
- **Command actions** – Extend `CommandExecutor.kt` to add new commands.
- **Permissions** – Modify `AndroidManifest.xml` to add/remove requested permissions.
- **UI** – Layouts are in `res/layout/`; they can be themed as needed.

---

## 🤝 Contributing

We welcome contributions that enhance the project **for legitimate security research**.  
If you have ideas for:
- Improved evasion techniques (for defensive research).
- New data exfiltration modules.
- Better UI/UX.
- Bug fixes or optimisations.

Please **open an issue** or submit a **pull request**. Ensure your code is well‑documented and tested.

---

## 📄 License

This project is released under the **MIT License**. See [LICENSE](LICENSE) for full details.

---

## ⚠️ FINAL WARNING

> **This software is intended exclusively for authorised security testing, educational purposes, and research.**  
> **Unauthorised access to any device or data is a criminal offence.**  
> The authors do not endorse or condone any illegal use.  
> **By using this tool, you agree that you are solely responsible for your actions and that the creators bear no liability.**

---

**Built with 🖤 and ☕ by the Genetic Team**  
*Stay curious, stay ethical.*
```
